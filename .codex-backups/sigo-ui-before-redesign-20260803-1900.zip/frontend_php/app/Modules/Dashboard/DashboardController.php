<?php

namespace App\Modules\Dashboard;

use App\Core\ApiClient;
use App\Core\AuthSession;
use App\Core\Config;
use App\Core\View;

final class DashboardController
{
    public function index(): void
    {
        if (!AuthSession::check()) {
            header('Location: /');
            return;
        }

        $menu = [];
        $error = null;

        try {
            $api = new ApiClient(Config::get('API_BASE_URL'), AuthSession::token());
            $response = $api->get('configuracion/mi-estructura');
            $menu = $response['datos'] ?? [];
        } catch (\Throwable $exception) {
            $error = $exception->getMessage();
        }

        View::render('dashboard/index', [
            'usuario' => AuthSession::user(),
            'menu' => $menu,
            'error' => $error,
        ]);
    }
}
