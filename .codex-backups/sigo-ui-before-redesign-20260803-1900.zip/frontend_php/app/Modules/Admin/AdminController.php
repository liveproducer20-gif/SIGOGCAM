<?php

namespace App\Modules\Admin;

use App\Core\ApiClient;
use App\Core\AuthSession;
use App\Core\Config;
use App\Core\View;

final class AdminController
{
    public function index(?string $message = null): void
    {
        if (!AuthSession::check()) {
            header('Location: /');
            return;
        }

        $data = [
            'eas' => [],
            'moviles' => [],
            'rutas' => [],
            'lugares' => [],
            'grados' => [],
            'distritos' => [],
            'tiposMovil' => [],
            'estadosMovil' => [],
        ];
        $error = null;

        try {
            $api = new ApiClient(Config::get('API_BASE_URL'), AuthSession::token());
            $data['eas'] = $api->get('admin/eas')['datos'] ?? [];
            $data['moviles'] = $api->get('admin/moviles')['datos'] ?? [];
            $data['rutas'] = $api->get('admin/rutas')['datos'] ?? [];
            $data['lugares'] = $api->get('admin/lugares-servicio')['datos'] ?? [];
            $data['grados'] = $api->get('admin/grados')['datos'] ?? [];
            $data['distritos'] = $api->get('catalogos/DISTRITOS')['datos'] ?? [];
            $data['tiposMovil'] = $api->get('catalogos/TIPOS_MOVIL')['datos'] ?? [];
            $data['estadosMovil'] = $api->get('catalogos/ESTADOS_MOVIL')['datos'] ?? [];
        } catch (\Throwable $exception) {
            $error = $exception->getMessage();
        }

        View::render('admin/index', [
            'data' => $data,
            'message' => $message,
            'error' => $error,
        ]);
    }

    public function store(): void
    {
        if (!AuthSession::check()) {
            header('Location: /');
            return;
        }

        $entity = $_POST['entity'] ?? '';
        $id = (int)($_POST['id'] ?? 0);

        try {
            $api = new ApiClient(Config::get('API_BASE_URL'), AuthSession::token());
            [$path, $payload] = $this->payloadFor($entity);
            if ($id > 0) {
                $api->put("admin/{$path}/{$id}", $payload);
                $this->index('Registro actualizado correctamente.');
                return;
            }
            $api->post("admin/{$path}", $payload);
            $this->index('Registro creado correctamente.');
        } catch (\Throwable $exception) {
            $this->index($exception->getMessage());
        }
    }

    public function destroy(): void
    {
        if (!AuthSession::check()) {
            header('Location: /');
            return;
        }

        $entity = $_POST['entity'] ?? '';
        $id = (int)($_POST['id'] ?? 0);
        $paths = [
            'eas' => 'eas',
            'movil' => 'moviles',
            'ruta' => 'rutas',
            'lugar' => 'lugares-servicio',
            'grado' => 'grados',
        ];

        if ($id <= 0 || !isset($paths[$entity])) {
            $this->index('Seleccione un registro válido.');
            return;
        }

        try {
            $api = new ApiClient(Config::get('API_BASE_URL'), AuthSession::token());
            $api->delete('admin/' . $paths[$entity] . '/' . $id);
            $this->index('Registro desactivado correctamente.');
        } catch (\Throwable $exception) {
            $this->index($exception->getMessage());
        }
    }

    private function payloadFor(string $entity): array
    {
        return match ($entity) {
            'eas' => ['eas', [
                'codigo' => trim($_POST['codigo'] ?? ''),
                'nombre' => trim($_POST['nombre'] ?? ''),
                'direccion' => trim($_POST['direccion'] ?? ''),
                'ubicacion' => trim($_POST['ubicacion'] ?? ''),
                'distritoId' => $this->nullableInt($_POST['distrito_id'] ?? null),
                'activo' => isset($_POST['activo']),
            ]],
            'movil' => ['moviles', [
                'numeroMovil' => trim($_POST['numero_movil'] ?? ''),
                'placa' => trim($_POST['placa'] ?? ''),
                'tipoMovilId' => (int)($_POST['tipo_movil_id'] ?? 0),
                'estadoMovilId' => (int)($_POST['estado_movil_id'] ?? 0),
                'kilometrajeActual' => (int)($_POST['kilometraje_actual'] ?? 0),
                'kilometrajeUltimoMantenimiento' => (int)($_POST['kilometraje_ultimo_mantenimiento'] ?? 0),
                'proximoMantenimiento' => $this->nullableInt($_POST['proximo_mantenimiento'] ?? null),
                'observacion' => trim($_POST['observacion'] ?? ''),
                'activo' => isset($_POST['activo']),
            ]],
            'ruta' => ['rutas', [
                'nombre' => trim($_POST['nombre'] ?? ''),
                'activo' => isset($_POST['activo']),
            ]],
            'lugar' => ['lugares-servicio', [
                'direccion' => trim($_POST['direccion'] ?? ''),
                'distritoId' => (int)($_POST['distrito_id'] ?? 0),
                'rutaId' => (int)($_POST['ruta_id'] ?? 0),
                'horaEntrada' => trim($_POST['hora_entrada'] ?? ''),
                'horaSalida' => trim($_POST['hora_salida'] ?? ''),
                'consignas' => trim($_POST['consignas'] ?? ''),
                'activo' => isset($_POST['activo']),
            ]],
            'grado' => ['grados', [
                'nombre' => trim($_POST['nombre'] ?? ''),
                'activo' => isset($_POST['activo']),
            ]],
            default => throw new \InvalidArgumentException('Entidad administrativa no válida.'),
        };
    }

    private function nullableInt(mixed $value): ?int
    {
        $value = trim((string)$value);
        return $value === '' ? null : (int)$value;
    }
}
