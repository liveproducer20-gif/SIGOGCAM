<?php
use App\Core\AuthSession;
use App\Core\Config;

$usuarioActual = AuthSession::user();
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars(Config::get('APP_NAME', 'SIGO-GCAM')) ?></title>
    <link rel="stylesheet" href="/assets/css/app.css">
    <?php foreach (($pageStyles ?? []) as $style): ?>
        <link rel="stylesheet" href="<?= htmlspecialchars($style) ?>">
    <?php endforeach; ?>
</head>
<body>
    <main class="app-shell">
        <?php require $viewFile; ?>
    </main>
    <script src="/assets/js/app.js"></script>
    <?php foreach (($pageScripts ?? []) as $script): ?>
        <script src="<?= htmlspecialchars($script) ?>"></script>
    <?php endforeach; ?>
</body>
</html>
