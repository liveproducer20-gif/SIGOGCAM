<section class="dashboard">
    <header class="topbar">
        <div>
            <h1>Administración</h1>
            <p>Catálogos operativos principales.</p>
        </div>
        <a class="button-link" href="/dashboard">Volver</a>
    </header>

    <?php if (!empty($error)): ?>
        <div class="alert"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if (!empty($message)): ?>
        <div class="success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="module-grid">
        <article><h2>EAS</h2><p><?= count($data['eas'] ?? []) ?> registros</p></article>
        <article><h2>Móviles</h2><p><?= count($data['moviles'] ?? []) ?> registros</p></article>
        <article><h2>Rutas</h2><p><?= count($data['rutas'] ?? []) ?> registros</p></article>
        <article><h2>Lugares</h2><p><?= count($data['lugares'] ?? []) ?> registros</p></article>
        <article><h2>Grados</h2><p><?= count($data['grados'] ?? []) ?> registros</p></article>
    </div>

    <section class="content-grid admin-grid">
        <form class="form-panel" method="post" action="/admin" id="form-eas">
            <h2>EAS</h2>
            <input type="hidden" name="entity" value="eas">
            <label>ID para editar<input type="number" name="id" placeholder="Vacío para crear"></label>
            <label>Código<input name="codigo" required></label>
            <label>Nombre<input name="nombre" required></label>
            <label>Dirección<input name="direccion" required></label>
            <label>Ubicación<input name="ubicacion"></label>
            <label>Distrito ID<input type="number" name="distrito_id"></label>
            <label class="check-row"><input type="checkbox" name="activo" checked> Activo</label>
            <button type="submit">Guardar EAS</button>
        </form>

        <form class="form-panel" method="post" action="/admin" id="form-movil">
            <h2>Móvil</h2>
            <input type="hidden" name="entity" value="movil">
            <label>ID para editar<input type="number" name="id" placeholder="Vacío para crear"></label>
            <label>Número móvil<input name="numero_movil" required></label>
            <label>Placa<input name="placa"></label>
            <label>Tipo
                <select name="tipo_movil_id" required>
                    <?php foreach (($data['tiposMovil'] ?? []) as $item): ?>
                        <option value="<?= (int)$item['id'] ?>"><?= htmlspecialchars($item['nombre'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Estado
                <select name="estado_movil_id" required>
                    <?php foreach (($data['estadosMovil'] ?? []) as $item): ?>
                        <option value="<?= (int)$item['id'] ?>"><?= htmlspecialchars($item['nombre'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Kilometraje<input type="number" name="kilometraje_actual" value="0"></label>
            <label>Último mantenimiento<input type="number" name="kilometraje_ultimo_mantenimiento" value="0"></label>
            <label>Próximo mantenimiento<input type="number" name="proximo_mantenimiento"></label>
            <label>Observación<textarea name="observacion" rows="3"></textarea></label>
            <label class="check-row"><input type="checkbox" name="activo" checked> Activo</label>
            <button type="submit">Guardar móvil</button>
        </form>

        <form class="form-panel" method="post" action="/admin" id="form-ruta">
            <h2>Ruta</h2>
            <input type="hidden" name="entity" value="ruta">
            <label>ID para editar<input type="number" name="id" placeholder="Vacío para crear"></label>
            <label>Nombre<input name="nombre" required></label>
            <label class="check-row"><input type="checkbox" name="activo" checked> Activo</label>
            <button type="submit">Guardar ruta</button>
        </form>

        <form class="form-panel" method="post" action="/admin" id="form-lugar">
            <h2>Lugar de servicio</h2>
            <input type="hidden" name="entity" value="lugar">
            <label>ID para editar<input type="number" name="id" placeholder="Vacío para crear"></label>
            <label>Dirección<input name="direccion" required></label>
            <label>Distrito
                <select name="distrito_id" required>
                    <?php foreach (($data['distritos'] ?? []) as $item): ?>
                        <option value="<?= (int)$item['id'] ?>"><?= htmlspecialchars($item['nombre'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Ruta
                <select name="ruta_id" required>
                    <?php foreach (($data['rutas'] ?? []) as $item): ?>
                        <option value="<?= (int)$item['id'] ?>"><?= htmlspecialchars($item['nombre'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>Hora entrada<input name="hora_entrada"></label>
            <label>Hora salida<input name="hora_salida"></label>
            <label>Consignas<textarea name="consignas" rows="3"></textarea></label>
            <label class="check-row"><input type="checkbox" name="activo" checked> Activo</label>
            <button type="submit">Guardar lugar</button>
        </form>

        <form class="form-panel" method="post" action="/admin" id="form-grado">
            <h2>Grado</h2>
            <input type="hidden" name="entity" value="grado">
            <label>ID para editar<input type="number" name="id" placeholder="Vacío para crear"></label>
            <label>Nombre<input name="nombre" required></label>
            <label class="check-row"><input type="checkbox" name="activo" checked> Activo</label>
            <button type="submit">Guardar grado</button>
        </form>
    </section>

    <section class="table-wrap">
        <h2>Registros principales</h2>
        <table>
            <thead><tr><th>Tipo</th><th>ID</th><th>Nombre / código</th><th>Detalle</th><th>Acción</th></tr></thead>
            <tbody>
            <?php foreach (($data['eas'] ?? []) as $item): ?>
                <?php $payload = ['id'=>$item['id'],'codigo'=>$item['codigo'] ?? '','nombre'=>$item['nombre'] ?? '','direccion'=>$item['direccion'] ?? '','ubicacion'=>$item['ubicacion'] ?? '','activo'=>!empty($item['activo'])]; ?>
                <tr><td>EAS</td><td><?= (int)$item['id'] ?></td><td><?= htmlspecialchars(($item['codigo'] ?? '') . ' ' . ($item['nombre'] ?? '')) ?></td><td><?= htmlspecialchars($item['direccion'] ?? '') ?></td><td><button type="button" class="secondary" data-edit-target="#form-eas" data-payload="<?= htmlspecialchars(json_encode($payload, JSON_UNESCAPED_UNICODE)) ?>">Editar</button><?php $entity='eas'; $id=(int)$item['id']; include __DIR__ . '/delete_form.php'; ?></td></tr>
            <?php endforeach; ?>
            <?php foreach (($data['moviles'] ?? []) as $item): ?>
                <?php $payload = ['id'=>$item['id'],'numero_movil'=>$item['numero_movil'] ?? '','placa'=>$item['placa'] ?? '','kilometraje_actual'=>$item['kilometraje_actual'] ?? 0,'activo'=>!empty($item['activo'])]; ?>
                <tr><td>Móvil</td><td><?= (int)$item['id'] ?></td><td><?= htmlspecialchars($item['numero_movil'] ?? '') ?></td><td><?= htmlspecialchars($item['placa'] ?? '') ?></td><td><button type="button" class="secondary" data-edit-target="#form-movil" data-payload="<?= htmlspecialchars(json_encode($payload, JSON_UNESCAPED_UNICODE)) ?>">Editar</button><?php $entity='movil'; $id=(int)$item['id']; include __DIR__ . '/delete_form.php'; ?></td></tr>
            <?php endforeach; ?>
            <?php foreach (($data['rutas'] ?? []) as $item): ?>
                <?php $payload = ['id'=>$item['id'],'nombre'=>$item['nombre'] ?? '','activo'=>!empty($item['activo'])]; ?>
                <tr><td>Ruta</td><td><?= (int)$item['id'] ?></td><td><?= htmlspecialchars($item['nombre'] ?? '') ?></td><td></td><td><button type="button" class="secondary" data-edit-target="#form-ruta" data-payload="<?= htmlspecialchars(json_encode($payload, JSON_UNESCAPED_UNICODE)) ?>">Editar</button><?php $entity='ruta'; $id=(int)$item['id']; include __DIR__ . '/delete_form.php'; ?></td></tr>
            <?php endforeach; ?>
            <?php foreach (($data['lugares'] ?? []) as $item): ?>
                <?php $payload = ['id'=>$item['id'],'direccion'=>$item['direccion'] ?? '','activo'=>!empty($item['activo'])]; ?>
                <tr><td>Lugar</td><td><?= (int)$item['id'] ?></td><td><?= htmlspecialchars($item['nombre'] ?? '') ?></td><td><?= htmlspecialchars($item['direccion'] ?? '') ?></td><td><button type="button" class="secondary" data-edit-target="#form-lugar" data-payload="<?= htmlspecialchars(json_encode($payload, JSON_UNESCAPED_UNICODE)) ?>">Editar</button><?php $entity='lugar'; $id=(int)$item['id']; include __DIR__ . '/delete_form.php'; ?></td></tr>
            <?php endforeach; ?>
            <?php foreach (($data['grados'] ?? []) as $item): ?>
                <?php $payload = ['id'=>$item['id'],'nombre'=>$item['nombre'] ?? '','activo'=>!empty($item['activo'])]; ?>
                <tr><td>Grado</td><td><?= (int)$item['id'] ?></td><td><?= htmlspecialchars($item['nombre'] ?? '') ?></td><td></td><td><button type="button" class="secondary" data-edit-target="#form-grado" data-payload="<?= htmlspecialchars(json_encode($payload, JSON_UNESCAPED_UNICODE)) ?>">Editar</button><?php $entity='grado'; $id=(int)$item['id']; include __DIR__ . '/delete_form.php'; ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</section>
