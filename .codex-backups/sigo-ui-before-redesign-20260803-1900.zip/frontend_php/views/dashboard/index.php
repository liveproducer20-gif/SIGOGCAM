<section class="dashboard">
    <header class="topbar">
        <div>
            <h1>Panel principal</h1>
            <p>Bienvenido, <?= htmlspecialchars(($usuario['nombres'] ?? '') . ' ' . ($usuario['apellidos'] ?? '')) ?></p>
        </div>
        <form method="post" action="/logout">
            <a class="button secondary" href="/perfil">Mi perfil</a>
            <button type="submit" class="secondary">Cerrar sesión</button>
        </form>
    </header>

    <?php if (!empty($error)): ?>
        <div class="alert">No se pudo cargar el menu dinamico: <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if (!empty($menu)): ?>
        <section class="menu-section">
            <h2>Módulos disponibles</h2>
            <div class="module-grid">
                <?php foreach ($menu as $item): ?>
                    <article>
                        <h3><?= htmlspecialchars($item['nombre'] ?? 'Módulo') ?></h3>
                        <p><?= htmlspecialchars($item['codigo'] ?? '') ?></p>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <div class="module-grid">
        <article>
            <h2>Cartillas</h2>
            <p>Generador institucional de reportes operativos.</p>
            <a class="card-action" href="/cartillas">Abrir</a>
        </article>
        <article>
            <h2>Eventos y anuncios</h2>
            <p>Gestión de convocatorias, publicaciones y notificaciones.</p>
            <a class="card-action" href="/eventos">Eventos</a>
            <a class="card-action secondary-action" href="/anuncios">Anuncios</a>
        </article>
        <article>
            <h2>Administración</h2>
            <p>Catálogos, personal, EAS, móviles, rutas y permisos.</p>
            <a class="card-action" href="/personal">Personal</a>
            <a class="card-action secondary-action" href="/admin">Catalogos</a>
        </article>
        <article>
            <h2>Insignias</h2>
            <p>Seguimiento de logros por cartillas generadas.</p>
            <a class="card-action" href="/insignias">Abrir</a>
        </article>
        <article>
            <h2>Soporte</h2>
            <p>Registro y seguimiento de alertas internas.</p>
            <a class="card-action" href="/soporte">Abrir</a>
        </article>
        <article>
            <h2>Configuración</h2>
            <p>Revisión de roles, permisos y estructura del menú.</p>
            <a class="card-action" href="/configuracion">Abrir</a>
        </article>
    </div>
</section>
