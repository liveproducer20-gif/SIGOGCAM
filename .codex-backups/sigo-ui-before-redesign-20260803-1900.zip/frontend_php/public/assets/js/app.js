(function () {
    const dragList = document.getElementById('menuDragList');
    if (dragList) {
        let dragged = null;
        dragList.querySelectorAll('.drag-row').forEach((row) => {
            row.addEventListener('dragstart', () => {
                dragged = row;
                row.classList.add('is-dragging');
            });
            row.addEventListener('dragend', () => {
                row.classList.remove('is-dragging');
                dragged = null;
                renumberRows(dragList);
            });
            row.addEventListener('dragover', (event) => {
                event.preventDefault();
                const target = event.currentTarget;
                if (!dragged || dragged === target) return;
                const rect = target.getBoundingClientRect();
                const before = event.clientY < rect.top + rect.height / 2;
                dragList.insertBefore(dragged, before ? target : target.nextSibling);
            });
        });
    }

    document.querySelectorAll('[data-edit-target]').forEach((button) => {
        button.addEventListener('click', () => {
            const target = document.querySelector(button.dataset.editTarget);
            if (!target) return;
            const payload = JSON.parse(button.dataset.payload || '{}');
            Object.keys(payload).forEach((key) => {
                const field = target.querySelector(`[name="${key}"]`);
                if (!field) return;
                if (field.type === 'checkbox') {
                    field.checked = Boolean(payload[key]);
                } else {
                    field.value = payload[key] ?? '';
                }
            });
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });

    function renumberRows(list) {
        list.querySelectorAll('.drag-row').forEach((row, index) => {
            const input = row.querySelector('.order-input');
            if (input) input.value = String(index + 1);
        });
    }
})();
