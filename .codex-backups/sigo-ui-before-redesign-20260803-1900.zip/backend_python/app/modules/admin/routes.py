from fastapi import APIRouter, Body, Depends

from app.core.responses import ok
from app.middleware.auth import current_user
from app.modules.admin.repository import (
    create_eas,
    create_grade,
    create_mobile_unit,
    create_route,
    create_service_place,
    delete_eas,
    delete_grade,
    delete_mobile_unit,
    delete_route,
    delete_service_place,
    list_eas,
    list_grades,
    list_mobile_units,
    list_routes,
    list_service_places,
    update_eas,
    update_grade,
    update_mobile_unit,
    update_route,
    update_service_place,
)


router = APIRouter(tags=["administracion"])


@router.get("/eas")
def eas(user: dict = Depends(current_user)):
    return ok(list_eas())


@router.post("/eas", status_code=201)
def crear_eas(payload: dict = Body(...), user: dict = Depends(current_user)):
    new_id = create_eas(payload)
    return {**ok(None, "EAS creada correctamente"), "id": new_id}


@router.put("/eas/{item_id}")
def actualizar_eas(item_id: int, payload: dict = Body(...), user: dict = Depends(current_user)):
    update_eas(item_id, payload)
    return ok(None, "EAS actualizada correctamente")


@router.delete("/eas/{item_id}")
def eliminar_eas(item_id: int, user: dict = Depends(current_user)):
    delete_eas(item_id)
    return ok(None, "EAS desactivada correctamente")


@router.get("/moviles")
def moviles(user: dict = Depends(current_user)):
    return ok(list_mobile_units())


@router.post("/moviles", status_code=201)
def crear_movil(payload: dict = Body(...), user: dict = Depends(current_user)):
    new_id = create_mobile_unit(payload)
    return {**ok(None, "Móvil creado correctamente"), "id": new_id}


@router.put("/moviles/{item_id}")
def actualizar_movil(item_id: int, payload: dict = Body(...), user: dict = Depends(current_user)):
    update_mobile_unit(item_id, payload)
    return ok(None, "Móvil actualizado correctamente")


@router.delete("/moviles/{item_id}")
def eliminar_movil(item_id: int, user: dict = Depends(current_user)):
    delete_mobile_unit(item_id)
    return ok(None, "Móvil desactivado correctamente")


@router.get("/rutas")
def rutas(user: dict = Depends(current_user)):
    return ok(list_routes())


@router.post("/rutas", status_code=201)
def crear_ruta(payload: dict = Body(...), user: dict = Depends(current_user)):
    new_id = create_route(payload)
    return {**ok(None, "Ruta creada correctamente"), "id": new_id}


@router.put("/rutas/{item_id}")
def actualizar_ruta(item_id: int, payload: dict = Body(...), user: dict = Depends(current_user)):
    update_route(item_id, payload)
    return ok(None, "Ruta actualizada correctamente")


@router.delete("/rutas/{item_id}")
def eliminar_ruta(item_id: int, user: dict = Depends(current_user)):
    delete_route(item_id)
    return ok(None, "Ruta desactivada correctamente")


@router.get("/lugares-servicio")
def lugares_servicio(user: dict = Depends(current_user)):
    return ok(list_service_places())


@router.post("/lugares-servicio", status_code=201)
def crear_lugar(payload: dict = Body(...), user: dict = Depends(current_user)):
    new_id = create_service_place(payload)
    return {**ok(None, "Lugar de servicio creado correctamente"), "id": new_id}


@router.put("/lugares-servicio/{item_id}")
def actualizar_lugar(item_id: int, payload: dict = Body(...), user: dict = Depends(current_user)):
    update_service_place(item_id, payload)
    return ok(None, "Lugar de servicio actualizado correctamente")


@router.delete("/lugares-servicio/{item_id}")
def eliminar_lugar(item_id: int, user: dict = Depends(current_user)):
    delete_service_place(item_id)
    return ok(None, "Lugar de servicio desactivado correctamente")


@router.get("/grados")
def grados(user: dict = Depends(current_user)):
    return ok(list_grades())


@router.post("/grados", status_code=201)
def crear_grado(payload: dict = Body(...), user: dict = Depends(current_user)):
    new_id = create_grade(payload)
    return {**ok(None, "Grado creado correctamente"), "id": new_id}


@router.put("/grados/{item_id}")
def actualizar_grado(item_id: int, payload: dict = Body(...), user: dict = Depends(current_user)):
    update_grade(item_id, payload)
    return ok(None, "Grado actualizado correctamente")


@router.delete("/grados/{item_id}")
def eliminar_grado(item_id: int, user: dict = Depends(current_user)):
    delete_grade(item_id)
    return ok(None, "Grado desactivado correctamente")
