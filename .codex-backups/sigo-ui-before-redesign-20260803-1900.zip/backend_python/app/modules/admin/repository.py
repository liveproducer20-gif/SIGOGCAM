from app.core.db import get_connection


def _rows(cursor) -> list[dict]:
    columns = [column[0] for column in cursor.description]
    return [dict(zip(columns, row)) for row in cursor.fetchall()]


def _query(sql: str, *params) -> list[dict]:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(sql, *params)
        return _rows(cursor)


def _table_exists(connection, table_name: str) -> bool:
    cursor = connection.cursor()
    cursor.execute(
        """
        SELECT 1
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = ?
        """,
        table_name,
    )
    return cursor.fetchone() is not None


def list_eas() -> list[dict]:
    with get_connection() as connection:
        cursor = connection.cursor()
        if _table_exists(connection, "eas"):
            cursor.execute(
                """
                SELECT id, codigo, nombre, direccion, activo
                FROM dbo.eas
                ORDER BY codigo, nombre
                """
            )
        else:
            cursor.execute(
                """
                SELECT id, codigo, nombre, direccion, activo
                FROM dbo.eas_estaciones
                ORDER BY codigo, nombre
                """
            )
        return _rows(cursor)


def list_mobile_units() -> list[dict]:
    return _query(
        """
        SELECT id, numero_movil, placa, kilometraje_actual, activo
        FROM dbo.moviles
        ORDER BY numero_movil
        """
    )


def list_routes() -> list[dict]:
    return _query(
        """
        SELECT id, nombre, CAST(NULL AS NVARCHAR(255)) AS descripcion, activo
        FROM dbo.rutas
        ORDER BY nombre
        """
    )


def list_service_places() -> list[dict]:
    return _query(
        """
        SELECT id, direccion AS nombre, direccion, activo
        FROM dbo.lugares_servicio
        ORDER BY direccion
        """
    )


def list_grades() -> list[dict]:
    return _query(
        """
        SELECT id, nombre, CAST(NULL AS NVARCHAR(40)) AS abreviatura, activo
        FROM dbo.grados
        ORDER BY nombre
        """
    )


def create_grade(data: dict) -> int:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            INSERT INTO dbo.grados (nombre, activo, fecha_creacion)
            OUTPUT INSERTED.id
            VALUES (?, ?, SYSDATETIME())
            """,
            data["nombre"],
            1 if data.get("activo", True) else 0,
        )
        return int(cursor.fetchone()[0])


def update_grade(item_id: int, data: dict) -> None:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            UPDATE dbo.grados
            SET nombre = ?, activo = ?, fecha_actualizacion = SYSDATETIME()
            WHERE id = ?
            """,
            data["nombre"],
            1 if data.get("activo", True) else 0,
            item_id,
        )


def delete_grade(item_id: int) -> None:
    _soft_delete("grados", item_id)


def create_route(data: dict) -> int:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            INSERT INTO dbo.rutas (nombre, activo, fecha_creacion)
            OUTPUT INSERTED.id
            VALUES (?, ?, SYSDATETIME())
            """,
            data["nombre"],
            1 if data.get("activo", True) else 0,
        )
        return int(cursor.fetchone()[0])


def update_route(item_id: int, data: dict) -> None:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            UPDATE dbo.rutas
            SET nombre = ?, activo = ?, fecha_actualizacion = SYSDATETIME()
            WHERE id = ?
            """,
            data["nombre"],
            1 if data.get("activo", True) else 0,
            item_id,
        )


def delete_route(item_id: int) -> None:
    _soft_delete("rutas", item_id)


def create_eas(data: dict) -> int:
    table = _eas_table()
    with get_connection() as connection:
        cursor = connection.cursor()
        if table == "eas":
            cursor.execute(
                """
                INSERT INTO dbo.eas (codigo, nombre, direccion, activo)
                OUTPUT INSERTED.id
                VALUES (?, ?, ?, ?)
                """,
                data["codigo"],
                data["nombre"],
                data["direccion"],
                1 if data.get("activo", True) else 0,
            )
        else:
            cursor.execute(
                """
                INSERT INTO dbo.eas_estaciones (codigo, nombre, direccion, ubicacion, activo, distrito_id, fecha_creacion)
                OUTPUT INSERTED.id
                VALUES (?, ?, ?, ?, ?, ?, SYSDATETIME())
                """,
                data["codigo"],
                data["nombre"],
                data["direccion"],
                data.get("ubicacion"),
                1 if data.get("activo", True) else 0,
                data.get("distritoId"),
            )
        return int(cursor.fetchone()[0])


def update_eas(item_id: int, data: dict) -> None:
    table = _eas_table()
    with get_connection() as connection:
        cursor = connection.cursor()
        if table == "eas":
            cursor.execute(
                """
                UPDATE dbo.eas
                SET codigo = ?, nombre = ?, direccion = ?, activo = ?
                WHERE id = ?
                """,
                data["codigo"],
                data["nombre"],
                data["direccion"],
                1 if data.get("activo", True) else 0,
                item_id,
            )
        else:
            cursor.execute(
                """
                UPDATE dbo.eas_estaciones
                SET codigo = ?, nombre = ?, direccion = ?, ubicacion = ?, activo = ?,
                    distrito_id = ?, fecha_actualizacion = SYSDATETIME()
                WHERE id = ?
                """,
                data["codigo"],
                data["nombre"],
                data["direccion"],
                data.get("ubicacion"),
                1 if data.get("activo", True) else 0,
                data.get("distritoId"),
                item_id,
            )


def delete_eas(item_id: int) -> None:
    _soft_delete(_eas_table(), item_id)


def create_mobile_unit(data: dict) -> int:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            INSERT INTO dbo.moviles (
                numero_movil, placa, tipo_movil_id, kilometraje_actual,
                kilometraje_ultimo_mantenimiento, proximo_mantenimiento,
                estado_movil_id, observacion, activo, fecha_creacion
            )
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATETIME())
            """,
            data["numeroMovil"],
            data.get("placa"),
            data["tipoMovilId"],
            data.get("kilometrajeActual", 0),
            data.get("kilometrajeUltimoMantenimiento", 0),
            data.get("proximoMantenimiento"),
            data["estadoMovilId"],
            data.get("observacion"),
            1 if data.get("activo", True) else 0,
        )
        return int(cursor.fetchone()[0])


def update_mobile_unit(item_id: int, data: dict) -> None:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            UPDATE dbo.moviles
            SET numero_movil = ?, placa = ?, tipo_movil_id = ?, kilometraje_actual = ?,
                kilometraje_ultimo_mantenimiento = ?, proximo_mantenimiento = ?,
                estado_movil_id = ?, observacion = ?, activo = ?, fecha_actualizacion = SYSDATETIME()
            WHERE id = ?
            """,
            data["numeroMovil"],
            data.get("placa"),
            data["tipoMovilId"],
            data.get("kilometrajeActual", 0),
            data.get("kilometrajeUltimoMantenimiento", 0),
            data.get("proximoMantenimiento"),
            data["estadoMovilId"],
            data.get("observacion"),
            1 if data.get("activo", True) else 0,
            item_id,
        )


def delete_mobile_unit(item_id: int) -> None:
    _soft_delete("moviles", item_id)


def create_service_place(data: dict) -> int:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            INSERT INTO dbo.lugares_servicio (
                direccion, distrito_id, ruta_id, hora_entrada, hora_salida,
                consignas, activo, fecha_creacion
            )
            OUTPUT INSERTED.id
            VALUES (?, ?, ?, ?, ?, ?, ?, SYSDATETIME())
            """,
            data["direccion"],
            data["distritoId"],
            data["rutaId"],
            data.get("horaEntrada"),
            data.get("horaSalida"),
            data.get("consignas"),
            1 if data.get("activo", True) else 0,
        )
        return int(cursor.fetchone()[0])


def update_service_place(item_id: int, data: dict) -> None:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            UPDATE dbo.lugares_servicio
            SET direccion = ?, distrito_id = ?, ruta_id = ?, hora_entrada = ?,
                hora_salida = ?, consignas = ?, activo = ?, fecha_actualizacion = SYSDATETIME()
            WHERE id = ?
            """,
            data["direccion"],
            data["distritoId"],
            data["rutaId"],
            data.get("horaEntrada"),
            data.get("horaSalida"),
            data.get("consignas"),
            1 if data.get("activo", True) else 0,
            item_id,
        )


def delete_service_place(item_id: int) -> None:
    _soft_delete("lugares_servicio", item_id)


def _soft_delete(table_name: str, item_id: int) -> None:
    if table_name not in {"eas", "eas_estaciones", "moviles", "rutas", "lugares_servicio", "grados"}:
        raise ValueError("Tabla no permitida")
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            f"UPDATE dbo.{table_name} SET activo = 0, fecha_actualizacion = SYSDATETIME() WHERE id = ?",
            item_id,
        )


def _eas_table() -> str:
    with get_connection() as connection:
        return "eas" if _table_exists(connection, "eas") else "eas_estaciones"
